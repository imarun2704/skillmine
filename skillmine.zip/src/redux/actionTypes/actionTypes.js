export const actionTypes = {
    VIEW_PRODUCT: 'VIEW_PRODUCT',
    ADD_TO_CART:'ADD_TO_CART',
};