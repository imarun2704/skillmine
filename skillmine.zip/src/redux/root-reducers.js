import { combineReducers } from "redux";
import Reducer from "./reducers/reducer";

export default combineReducers({
  Reducer: Reducer,
});
